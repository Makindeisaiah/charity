<?php

// ? Logs errors into an array 
$errors = [];


// // ? REGISTER USER
// if (isset($_POST['submit'])) {
//   // echo 'working';
//   // ? receive all input values from the form
//   $full_name = $_POST['full_name'];
//   $email = $_POST['email'];
//   $gender = $_POST['gender'];
//   $phone_number = $_POST['phone_number'];
//   $location = $_POST['location'];

//   if (empty($full_name)) {
//     array_push($errors, "Full name is required");
//   }
//   if (empty($email)) {
//     array_push($errors, "email is required");
//   }
//   if (empty($gender)) {
//     array_push($errors, "Full name is required");
//   }
//   if (empty($phone_number)) {
//     array_push($errors, "Phone number is required");
//   }
//   if (empty($location)) {
//     array_push($errors, "Location is required");
//   }
  
//   // ? first check the database to make sure 
//   // ? a user does not already exist with the same username and/or email
//   $result = $pdo->prepare("SELECT * FROM volunteer WHERE email= ? OR phone_number= ? LIMIT 1");

//   $result->execute([$email, $phone_number]);

//   $user = $result->fetch(PDO::FETCH_ASSOC);

//   if ($user) { // ? if user exists
//     if ($user['email'] === $email) {
//       array_push($errors, "email already exists");
//     }

//     if ($user['phone_number'] === $phone_number) {
//       array_push($errors, "phone_number already exists");
//     }
//   }

//   // ? Finally, register user if there are no errors in the form
//   if (count($errors) == 0) {

//     // ? inserting the user information into the datatbase 
//     $stp = $pdo->prepare('INSERT INTO `volunteer` (`full_name`, `email`, `gender`, `phone_number`, `location`) VALUES (?, ?, ?, ?, ?)');

//     echo 'sent';

  
// }
// }

// initializing variables
$username = "";
$email    = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'validreams_foundation');






// REGISTER USER
if (isset($_POST['submit'])) {
  // receive all input values from the form
  $full_name = mysqli_real_escape_string($db, $_POST['full_name']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $gender = mysqli_real_escape_string($db, $_POST['gender']);
  $phone_number = mysqli_real_escape_string($db, $_POST['phone_number']);
  $location = mysqli_real_escape_string($db, $_POST['location']);


  // form validation: ensure that the form is correctly filled ...
  // by adding (array_push()) corresponding error unto $errors array
  // if (empty($full_name)) { array_push($errors, "username is required"); }
  // if (empty($email)) { array_push($errors, "email is required"); }
  // if (empty($gender)) { array_push($errors, "Gender is required"); }
  // if (empty($phone_number)) { array_push($errors, "phone_number is required"); }
  // if (empty($location)) { array_push($errors, "Gender is required"); }
  
  

  // first check the database to make sure 
  // a user does not already exist with the same username and/or email
  $user_check_query = "SELECT * FROM volunteer WHERE email='$email' OR phone_number='$phone_number' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { // if user exists
    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }

    if ($user['phone_number'] === $phone_number) {
      array_push($errors, "phone_number already exists");
    }
  }

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {

  	$query = "INSERT INTO volunteer (full_name, email, gender, phone_number, location) 
  			  VALUES('$full_name', '$email', '$gender', '$phone_number', '$location')";
  	mysqli_query($db, $query);
  	
  	array_push($errors, "Congratulations, You're Welcome");
  }
}


// message
if (isset($_POST['submit_message'])) {
  // receive all input values from the form
  $name = mysqli_real_escape_string($db, $_POST['name']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $message = mysqli_real_escape_string($db, $_POST['message']);
 

  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) {

  	$query = "INSERT INTO messages (name, email, message) 
  			  VALUES('$name', '$email', '$message')";
  	mysqli_query($db, $query);
  	
  	array_push($errors, "Message Sent");
  }
}








// ? pagination for placed_bet

// $perPage = 2;

// $stmt = $pdo->query("SELECT count(*) FROM `blog`");
// $total_results = $stmt->fetchColumn();
// $total_pages = ceil($total_results / $perPage);

// // ? Current page
// $page = isset($_GET['page']) ? $_GET['page'] : 1;
// $offset = ($page - 1) * $perPage;


?>