<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>The Validreams Foundation</title>
    <meta name="description" content>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700%7CRoboto+Slab:400,700" rel="stylesheet">
    <link rel="icon" type="image/png" href="assets/images/favicon 2.png">

    <link rel="apple-touch-icon" href="apple-touch-icon.php">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/xsIcon.css">
    <link rel="stylesheet" href="assets/css/isotope.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">

    <link rel="stylesheet" href="assets/css/plugins.css" />

    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="stylesheet" href="assets/css/responsive.css" />
    <link rel="stylesheet alternate" title="color-1" type="text/css" href="assets/css/colors/color-1.css">
    <link rel="stylesheet alternate" title="color-2" type="text/css" href="assets/css/colors/color-2.css">
    <link rel="stylesheet alternate" title="color-3" type="text/css" href="assets/css/colors/color-3.css">
    <link rel="stylesheet alternate" title="color-4" type="text/css" href="assets/css/colors/color-4.css">
    <link rel="stylesheet alternate" title="color-5" type="text/css" href="assets/css/colors/color-5.css">
    <link rel="stylesheet alternate" title="color-6" type="text/css" href="assets/css/colors/color-6.css">
    <link rel="stylesheet alternate" title="color-7" type="text/css" href="assets/css/colors/color-7.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
</head>